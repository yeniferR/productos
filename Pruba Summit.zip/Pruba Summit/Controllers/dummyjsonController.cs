﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Pruba_Summit.Models;
using RestSharp;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Http;

namespace Pruba_Summit.Controllers
{
    //[ApiController]
    [Route("api/usuarios")]
    public class dummyjsonController : ApiController
    {
        [HttpGet]
        public object usuarios()
        {
            dummyjsonController usuarios = new dummyjsonController();
            //List<DatosUsuarios> listaUsario = new List<DatosUsuarios>();
            string user = usuarios.getUsuarios("https://dummyjson.com/users");
            string docPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            using (StreamWriter outputFile = new StreamWriter(Path.Combine(docPath, "Usuarios.txt")))
            {
                outputFile.WriteLine(user);
            }

            return user;
        }

        [HttpPost]

        public object productos()
        {
            RestResponse response = new RestResponse();
            RootobjectTokens tokens = null;
            RootobjectProductos productos = null;
            string docPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            StreamReader sr = new StreamReader((Path.Combine(docPath, "Usuarios.txt")));
            string lineUser = sr.ReadToEnd();
            Rootobject myDeserializedClass = JsonConvert.DeserializeObject<Rootobject>(lineUser);
           
                foreach (User userlist in myDeserializedClass.users)
                {
                   if (userlist.username == "atuny0" && userlist.password == "9uQFF1Lh")
                   {

                        var client = new RestClient();
                        var request = new RestRequest("https://dummyjson.com/auth/login",Method.Post);
                        request.AddHeader("Content-Type", "application/json");
                        request.AddParameter("application/json", " { \"username\": \"atuny0\", \r\n    \"password\": \"9uQFF1Lh\"\r\n }", ParameterType.RequestBody);
                        //request.RequestFormat = DataFormat.Json;
                        response = client.Execute(request);
                        tokens = JsonConvert.DeserializeObject<RootobjectTokens>(response.Content);

                        var clientproductos = new RestClient();
                        var requestproduco = new RestRequest("https://dummyjson.com/auth/products?limit=10", Method.Get);
                        requestproduco.AddHeader("Authorization", tokens.token);
                        RestResponse responseproducto = client.Execute(requestproduco);
                        productos = JsonConvert.DeserializeObject<RootobjectProductos>(responseproducto.Content);
                




                   }

                }


            return productos.products;
        }



        public string getUsuarios(String url)
        {
            HttpWebRequest datosUsuarios = (HttpWebRequest)WebRequest.Create(url);
            HttpWebResponse ResponseUsuarios = (HttpWebResponse)datosUsuarios.GetResponse();

            StreamReader user = new StreamReader(ResponseUsuarios.GetResponseStream());
            string result = user.ReadToEnd();
            user.Close();

            return result;
        }


    }
}   